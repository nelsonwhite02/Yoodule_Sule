<?php

echo "please enter this short code to your desired page [yoodule_stripe]My Text Here[/yoodule_stripe]";

?>